# DompetKu — Expense Tracker

Aplikasi pencatat pengeluaran harian berbasis web. Pure HTML + CSS + JavaScript (tanpa backend).

## Struktur File

```
expense-tracker/
├── index.html   → Struktur halaman utama
├── style.css    → Styling & tema dark modern
├── app.js       → Logika aplikasi & Chart.js
└── README.md    → Dokumentasi ini
```

## Cara Menjalankan

Cukup buka `index.html` di browser modern (Chrome, Firefox, Edge). Tidak perlu server.

## Fitur

- **Dashboard** — Statistik total, transaksi, rata-rata harian + mini line chart
- **Form Input** — Validasi lengkap: tanggal, nama, kategori, nominal
- **Tabel Data** — Edit & hapus setiap entri, total otomatis
- **Filter Bulan** — Filter global memengaruhi semua komponen
- **Grafik Bar** — Pengeluaran harian per tanggal
- **Doughnut Chart** — Distribusi per kategori
- **Batas Pengeluaran** — Warning otomatis jika terlampaui
- **Modal Ringkasan** — Tekan tombol ◎ di pojok kanan bawah
- **LocalStorage** — Data tersimpan permanen di browser

## Kategori

Makanan, Transportasi, Hiburan, Belanja, Kesehatan, Pendidikan, Tagihan, Lainnya

## Teknologi

- HTML5, CSS3, Vanilla JavaScript (ES6+)
- [Chart.js v4](https://www.chartjs.org/) via CDN
- Google Fonts: Sora + JetBrains Mono
