/* =====================================================
   DompetKu — Expense Tracker
   app.js | Logika Utama Aplikasi
===================================================== */

'use strict';

/* ══════════════════════════════════════════
   STATE & KONFIGURASI
══════════════════════════════════════════ */

// Data utama diambil dari localStorage
let entries = JSON.parse(localStorage.getItem('dompetku_entries') || '[]');
let limit   = parseFloat(localStorage.getItem('dompetku_limit') || '0');
let editId  = null; // ID data yang sedang di-edit

// Bulan aktif berdasarkan filter global (default: bulan ini)
let activeMonth = new Date().toISOString().slice(0, 7); // "YYYY-MM"

/* Palet warna untuk chart per kategori */
const CAT_COLORS = {
  makanan:    '#34d399',
  transport:  '#60a5fa',
  hiburan:    '#fbbf24',
  belanja:    '#f87171',
  kesehatan:  '#a78bfa',
  pendidikan: '#22d3ee',
  tagihan:    '#fb923c',
  lainnya:    '#94a3b8',
};

const CAT_EMOJI = {
  makanan:    '🍜',
  transport:  '🚗',
  hiburan:    '🎮',
  belanja:    '🛍️',
  kesehatan:  '💊',
  pendidikan: '📚',
  tagihan:    '⚡',
  lainnya:    '📦',
};

const CAT_LABEL = {
  makanan:    'Makanan & Minuman',
  transport:  'Transportasi',
  hiburan:    'Hiburan',
  belanja:    'Belanja',
  kesehatan:  'Kesehatan',
  pendidikan: 'Pendidikan',
  tagihan:    'Tagihan',
  lainnya:    'Lainnya',
};

/* Referensi Chart.js instances */
let dashChartInstance = null;
let mainChartInstance = null;
let catChartInstance  = null;

/* ══════════════════════════════════════════
   INISIALISASI
══════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {
  // Set tanggal default form ke hari ini
  document.getElementById('inp-date').value = todayStr();

  // Set filter bulan global ke bulan ini
  document.getElementById('global-month').value = activeMonth;

  // Isi limit jika ada
  if (limit > 0) document.getElementById('limit-input').value = limit;

  // Render semua komponen
  renderAll();

  // Cek batas setelah inisialisasi
  setTimeout(checkLimit, 600);
});

/* ══════════════════════════════════════════
   HELPER FUNGSI UMUM
══════════════════════════════════════════ */

/** Format angka ke Rupiah */
function fmt(n) {
  return 'Rp ' + Math.round(n).toLocaleString('id-ID');
}

/** Tanggal hari ini dalam format YYYY-MM-DD */
function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

/** Filter entries berdasarkan activeMonth */
function getFiltered() {
  return entries.filter(e => e.date.slice(0, 7) === activeMonth);
}

/** Simpan semua entries ke localStorage */
function saveToStorage() {
  localStorage.setItem('dompetku_entries', JSON.stringify(entries));
}

/** Label bulan yang ramah (cth: "April 2025") */
function monthLabel(ym) {
  if (!ym) return '—';
  const [y, m] = ym.split('-');
  const names = ['Januari','Februari','Maret','April','Mei','Juni',
                 'Juli','Agustus','September','Oktober','November','Desember'];
  return names[parseInt(m) - 1] + ' ' + y;
}

/** Dapatkan jumlah hari dalam bulan activeMonth */
function daysInMonth(ym) {
  const [y, m] = ym.split('-').map(Number);
  return new Date(y, m, 0).getDate();
}

/* ══════════════════════════════════════════
   NAVIGASI SECTION
══════════════════════════════════════════ */

document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', e => {
    e.preventDefault();
    const target = item.dataset.section;
    goSection(target);
    // Tutup sidebar di mobile setelah klik
    if (window.innerWidth <= 768) closeSidebar();
  });
});

function goSection(name) {
  // Update nav aktif
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const navEl = document.querySelector(`.nav-item[data-section="${name}"]`);
  if (navEl) navEl.classList.add('active');

  // Tampilkan section yang dipilih
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  const secEl = document.getElementById('section-' + name);
  if (secEl) secEl.classList.add('active');

  // Update judul topbar
  const titles = { dashboard:'Dashboard', transaksi:'Transaksi', grafik:'Grafik', pengaturan:'Pengaturan' };
  document.getElementById('page-title').textContent = titles[name] || name;

  // Render ulang chart jika berpindah ke section grafik
  if (name === 'grafik') renderCharts();
}

/* ══════════════════════════════════════════
   SIDEBAR (MOBILE)
══════════════════════════════════════════ */

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('overlay').classList.toggle('show');
}

function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('overlay').classList.remove('show');
}

/* ══════════════════════════════════════════
   FILTER BULAN GLOBAL
══════════════════════════════════════════ */

function onMonthChange() {
  const val = document.getElementById('global-month').value;
  if (val) activeMonth = val;
  renderAll();
}

/* ══════════════════════════════════════════
   FORM — SIMPAN & EDIT & HAPUS
══════════════════════════════════════════ */

/**
 * Menyimpan entri baru atau memperbarui entri yang sedang di-edit.
 * Dipanggil saat form disubmit.
 */
function saveEntry(e) {
  e.preventDefault();

  // Ambil nilai input
  const date   = document.getElementById('inp-date').value.trim();
  const name   = document.getElementById('inp-name').value.trim();
  const cat    = document.getElementById('inp-cat').value;
  const amount = parseFloat(document.getElementById('inp-amount').value);

  // Validasi manual
  let valid = true;

  if (!date) {
    showErr('err-date', 'Tanggal wajib diisi'); valid = false;
  } else clearErr('err-date');

  if (!name) {
    showErr('err-name', 'Nama pengeluaran wajib diisi'); valid = false;
  } else clearErr('err-name');

  if (!cat) {
    showErr('err-cat', 'Pilih kategori'); valid = false;
  } else clearErr('err-cat');

  if (!amount || amount <= 0 || isNaN(amount)) {
    showErr('err-amount', 'Nominal harus berupa angka positif'); valid = false;
  } else clearErr('err-amount');

  if (!valid) return;

  if (editId !== null) {
    // MODE EDIT — perbarui entri yang ada
    const idx = entries.findIndex(en => en.id === editId);
    if (idx > -1) {
      entries[idx] = { id: editId, date, name, cat, amount };
    }
    editId = null;
    document.getElementById('form-title').textContent = 'Tambah Pengeluaran';
    document.getElementById('btn-cancel-edit').style.display = 'none';
    document.getElementById('btn-save').innerHTML = '<span class="btn-icon-inner">+</span> Simpan Pengeluaran';
    showToast('Data diperbarui', `"${name}" berhasil diperbarui.`, 'success');
  } else {
    // MODE TAMBAH — buat entri baru
    const newEntry = {
      id: Date.now(),       // ID unik berbasis timestamp
      date, name, cat,
      amount
    };
    entries.unshift(newEntry); // Tambah ke depan array
    showToast('Tersimpan', `"${name}" berhasil ditambahkan.`, 'success');
  }

  // Simpan ke localStorage
  saveToStorage();

  // Reset form
  resetForm();

  // Render ulang semua komponen
  renderAll();

  // Cek batas pengeluaran
  checkLimit();
}

/** Edit entri — isi ulang form dengan data entri */
function editEntry(id) {
  const entry = entries.find(e => e.id === id);
  if (!entry) return;

  editId = id;
  document.getElementById('inp-date').value   = entry.date;
  document.getElementById('inp-name').value   = entry.name;
  document.getElementById('inp-cat').value    = entry.cat;
  document.getElementById('inp-amount').value = entry.amount;

  document.getElementById('form-title').textContent = 'Edit Pengeluaran';
  document.getElementById('btn-cancel-edit').style.display = '';
  document.getElementById('btn-save').innerHTML = '✓ Perbarui Data';

  // Scroll ke form
  goSection('transaksi');
  setTimeout(() => {
    document.getElementById('expense-form').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, 100);
}

/** Hapus satu entri */
function deleteEntry(id) {
  const entry = entries.find(e => e.id === id);
  if (!entry) return;

  if (!confirm(`Hapus "${entry.name}"? Tindakan ini tidak dapat dibatalkan.`)) return;

  entries = entries.filter(e => e.id !== id);
  saveToStorage();
  renderAll();
  showToast('Dihapus', `"${entry.name}" berhasil dihapus.`, 'error');
}

/** Batalkan mode edit */
function cancelEdit() {
  editId = null;
  resetForm();
  document.getElementById('form-title').textContent = 'Tambah Pengeluaran';
  document.getElementById('btn-cancel-edit').style.display = 'none';
  document.getElementById('btn-save').innerHTML = '<span class="btn-icon-inner">+</span> Simpan Pengeluaran';
}

/** Reset nilai-nilai form */
function resetForm() {
  document.getElementById('inp-date').value   = todayStr();
  document.getElementById('inp-name').value   = '';
  document.getElementById('inp-cat').value    = '';
  document.getElementById('inp-amount').value = '';
  ['err-date','err-name','err-cat','err-amount'].forEach(clearErr);
}

function showErr(id, msg) {
  document.getElementById(id).textContent = msg;
  // Tambahkan class error ke input yang bersangkutan
  const inputId = id.replace('err-', 'inp-');
  const el = document.getElementById(inputId);
  if (el) el.classList.add('error');
}

function clearErr(id) {
  document.getElementById(id).textContent = '';
  const inputId = id.replace('err-', 'inp-');
  const el = document.getElementById(inputId);
  if (el) el.classList.remove('error');
}

/* ══════════════════════════════════════════
   RENDER SEMUA KOMPONEN
══════════════════════════════════════════ */

/** Render ulang seluruh UI */
function renderAll() {
  renderStats();
  renderRecentList();
  renderTable();
  renderDashChart();
  renderCharts();
  updateStorageInfo();
}

/* ── Statistik ── */
function renderStats() {
  const filtered = getFiltered();
  const total    = filtered.reduce((s, e) => s + e.amount, 0);
  const count    = filtered.length;
  const days     = new Set(filtered.map(e => e.date)).size;
  const avg      = days > 0 ? total / days : 0;

  document.getElementById('stat-total').textContent      = fmt(total);
  document.getElementById('stat-count').textContent      = count;
  document.getElementById('stat-avg').textContent        = fmt(avg);
  document.getElementById('stat-month-label').textContent = monthLabel(activeMonth);
  document.getElementById('stat-active-days').textContent = days + ' hari aktif';

  // Update kartu limit jika ada
  const limitCard = document.getElementById('limit-card');
  if (limit > 0) {
    limitCard.style.display = '';
    const pct = Math.min((total / limit) * 100, 999);
    const rem = limit - total;
    document.getElementById('stat-limit-pct').textContent  = pct.toFixed(1) + '%';
    document.getElementById('stat-limit-rem').textContent  =
      rem >= 0 ? 'Sisa: ' + fmt(rem) : 'Lebih: ' + fmt(-rem);
  } else {
    limitCard.style.display = 'none';
  }

  // Update badge chart di dashboard
  document.getElementById('dash-chart-label').textContent = monthLabel(activeMonth);
  document.getElementById('chart-month-badge').textContent = monthLabel(activeMonth);
  document.getElementById('cat-month-badge').textContent   = monthLabel(activeMonth);
  document.getElementById('table-count-badge').textContent = count + ' data';
}

/* ── List Transaksi Terbaru (Dashboard) ── */
function renderRecentList() {
  const filtered = getFiltered();
  const recent   = [...filtered].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5);
  const container = document.getElementById('recent-list');

  if (recent.length === 0) {
    container.innerHTML = '<div class="empty-state">Belum ada transaksi bulan ini</div>';
    return;
  }

  container.innerHTML = recent.map(e => `
    <div class="recent-item">
      <div class="recent-icon cat-${e.cat}">${CAT_EMOJI[e.cat] || '📦'}</div>
      <div class="recent-info">
        <div class="recent-name">${escHtml(e.name)}</div>
        <div class="recent-date">${formatDate(e.date)} · ${CAT_LABEL[e.cat] || e.cat}</div>
      </div>
      <div class="recent-amount">${fmt(e.amount)}</div>
    </div>
  `).join('');
}

/* ── Tabel Pengeluaran ── */
function renderTable() {
  const filtered = getFiltered();
  const sorted   = [...filtered].sort((a, b) => b.date.localeCompare(a.date));
  const tbody    = document.getElementById('table-body');
  const emptyEl  = document.getElementById('table-empty');
  const totalRow = document.getElementById('table-total-row');

  if (sorted.length === 0) {
    tbody.innerHTML = '';
    emptyEl.style.display = '';
    totalRow.style.display = 'none';
    return;
  }

  emptyEl.style.display = 'none';
  totalRow.style.display = '';

  // Hitung total
  const total = sorted.reduce((s, e) => s + e.amount, 0);
  document.getElementById('table-total-val').textContent = fmt(total);

  // Isi baris tabel
  tbody.innerHTML = sorted.map(e => `
    <tr>
      <td style="white-space:nowrap;color:var(--text2);font-size:12px">${formatDate(e.date)}</td>
      <td style="max-width:200px">
        <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500">
          ${escHtml(e.name)}
        </div>
      </td>
      <td>
        <span class="cat-badge cat-${e.cat}">
          ${CAT_EMOJI[e.cat] || ''} ${CAT_LABEL[e.cat] || e.cat}
        </span>
      </td>
      <td class="align-right">
        <span class="amount-cell">${fmt(e.amount)}</span>
      </td>
      <td class="align-center" style="white-space:nowrap">
        <button class="tbl-action edit" onclick="editEntry(${e.id})" title="Edit">✏️</button>
        <button class="tbl-action del"  onclick="deleteEntry(${e.id})" title="Hapus">🗑️</button>
      </td>
    </tr>
  `).join('');
}

/* ══════════════════════════════════════════
   GRAFIK — CHART.JS
══════════════════════════════════════════ */

/** Buat data per-hari untuk bulan activeMonth */
function buildDailyData() {
  const total  = daysInMonth(activeMonth);
  const labels = Array.from({ length: total }, (_, i) => i + 1); // [1, 2, ..., 31]
  const data   = new Array(total).fill(0);

  const filtered = getFiltered();
  filtered.forEach(e => {
    const day = parseInt(e.date.split('-')[2], 10) - 1; // index 0-based
    data[day] += e.amount;
  });

  return { labels, data };
}

/** Opsi dasar Chart.js (dark theme) */
function chartDefaults() {
  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#1e2130',
        borderColor: 'rgba(255,255,255,0.1)',
        borderWidth: 1,
        titleColor: '#8890a8',
        bodyColor: '#e8eaf2',
        callbacks: {
          label: ctx => ' ' + fmt(ctx.raw)
        }
      }
    },
    scales: {
      x: {
        grid: { color: 'rgba(255,255,255,0.04)' },
        ticks: { color: '#555d78', font: { family: "'JetBrains Mono', monospace", size: 11 } }
      },
      y: {
        grid: { color: 'rgba(255,255,255,0.04)' },
        ticks: {
          color: '#555d78',
          font: { family: "'JetBrains Mono', monospace", size: 11 },
          callback: v => v === 0 ? '0' : (v >= 1000000 ? (v/1000000).toFixed(1)+'jt' : (v/1000).toFixed(0)+'rb')
        }
      }
    }
  };
}

/** Chart mini di Dashboard (line chart) */
function renderDashChart() {
  const { labels, data } = buildDailyData();
  const ctx = document.getElementById('dashChart').getContext('2d');

  if (dashChartInstance) dashChartInstance.destroy();

  // Gradient untuk area di bawah garis
  const grad = ctx.createLinearGradient(0, 0, 0, 180);
  grad.addColorStop(0, 'rgba(124,111,247,0.3)');
  grad.addColorStop(1, 'rgba(124,111,247,0)');

  dashChartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        data,
        borderColor:     '#7c6ff7',
        backgroundColor: grad,
        borderWidth:     2,
        pointRadius:     data.map(v => v > 0 ? 4 : 0),
        pointBackgroundColor: '#a89ef9',
        tension:         0.4,
        fill:            true,
      }]
    },
    options: {
      ...chartDefaults(),
      plugins: {
        ...chartDefaults().plugins,
      }
    }
  });
}

/** Chart utama di halaman Grafik (bar chart) */
function renderCharts() {
  renderMainBarChart();
  renderCatDoughnut();
}

function renderMainBarChart() {
  const { labels, data } = buildDailyData();
  const ctx = document.getElementById('mainChart').getContext('2d');

  if (mainChartInstance) mainChartInstance.destroy();

  // Warna bar tergantung nilai (lebih tinggi = lebih terang)
  const maxVal = Math.max(...data, 1);
  const colors = data.map(v => {
    const alpha = 0.3 + (v / maxVal) * 0.7;
    return `rgba(124,111,247,${alpha.toFixed(2)})`;
  });

  mainChartInstance = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Pengeluaran',
        data,
        backgroundColor: colors,
        borderColor: '#7c6ff7',
        borderWidth: 1,
        borderRadius: 4,
      }]
    },
    options: {
      ...chartDefaults(),
      plugins: {
        ...chartDefaults().plugins,
        tooltip: {
          ...chartDefaults().plugins.tooltip,
          callbacks: {
            title: ctx => `Tanggal ${ctx[0].label}`,
            label: ctx => ' ' + fmt(ctx.raw)
          }
        }
      }
    }
  });
}

/** Doughnut chart per kategori */
function renderCatDoughnut() {
  const filtered = getFiltered();
  const bycat    = {};

  filtered.forEach(e => {
    bycat[e.cat] = (bycat[e.cat] || 0) + e.amount;
  });

  const cats   = Object.keys(bycat).sort((a, b) => bycat[b] - bycat[a]);
  const vals   = cats.map(c => bycat[c]);
  const colors = cats.map(c => CAT_COLORS[c] || '#94a3b8');
  const total  = vals.reduce((s, v) => s + v, 0);

  const ctx = document.getElementById('catChart').getContext('2d');
  if (catChartInstance) catChartInstance.destroy();

  if (cats.length === 0) {
    // Gambar placeholder jika tidak ada data
    catChartInstance = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Tidak ada data'],
        datasets: [{ data: [1], backgroundColor: ['#1e2130'], borderWidth: 0 }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
    });
    document.getElementById('cat-legend').innerHTML = '<div class="empty-state">Belum ada data</div>';
    return;
  }

  catChartInstance = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: cats.map(c => CAT_LABEL[c] || c),
      datasets: [{
        data:            vals,
        backgroundColor: colors,
        borderColor:     '#13161e',
        borderWidth:     3,
        hoverOffset:     6,
      }]
    },
    options: {
      responsive:          true,
      maintainAspectRatio: false,
      cutout:              '65%',
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1e2130',
          borderColor:     'rgba(255,255,255,0.1)',
          borderWidth:     1,
          callbacks: {
            label: ctx => ' ' + fmt(ctx.raw) + ' (' + ((ctx.raw / total) * 100).toFixed(1) + '%)'
          }
        }
      }
    }
  });

  // Render legend kustom
  const legendEl = document.getElementById('cat-legend');
  legendEl.innerHTML = cats.map(c => `
    <div class="cat-legend-item">
      <div class="legend-dot" style="background:${CAT_COLORS[c] || '#94a3b8'}"></div>
      <span class="legend-name">${CAT_EMOJI[c] || ''} ${CAT_LABEL[c] || c}</span>
      <span class="legend-pct">${((bycat[c] / total) * 100).toFixed(0)}%</span>
    </div>
  `).join('');
}

/* ══════════════════════════════════════════
   MODAL RINGKASAN BULANAN
══════════════════════════════════════════ */

function showSummaryModal() {
  const filtered = getFiltered();
  const total    = filtered.reduce((s, e) => s + e.amount, 0);
  const count    = filtered.length;
  const days     = new Set(filtered.map(e => e.date)).size;
  const avg      = days > 0 ? total / days : 0;

  // Kategori terbesar
  const bycat = {};
  filtered.forEach(e => { bycat[e.cat] = (bycat[e.cat] || 0) + e.amount; });
  const topCat = Object.entries(bycat).sort((a, b) => b[1] - a[1])[0];

  const isOver = limit > 0 && total > limit;

  document.getElementById('modal-title').textContent = 'Ringkasan ' + monthLabel(activeMonth);
  document.getElementById('modal-icon').textContent  = isOver ? '⚠️' : '📊';

  let html = `
    <div class="modal-row highlight">
      <span class="modal-key">Total Pengeluaran</span>
      <span class="modal-val">${fmt(total)}</span>
    </div>
    <div class="modal-row">
      <span class="modal-key">Jumlah Transaksi</span>
      <span class="modal-val">${count}</span>
    </div>
    <div class="modal-row">
      <span class="modal-key">Hari Aktif</span>
      <span class="modal-val">${days} hari</span>
    </div>
    <div class="modal-row">
      <span class="modal-key">Rata-rata / Hari</span>
      <span class="modal-val">${fmt(avg)}</span>
    </div>
  `;

  if (topCat) {
    html += `
      <div class="modal-row">
        <span class="modal-key">Kategori Terbesar</span>
        <span class="modal-val">${CAT_EMOJI[topCat[0]] || ''} ${CAT_LABEL[topCat[0]] || topCat[0]}</span>
      </div>
    `;
  }

  if (limit > 0) {
    const pct = ((total / limit) * 100).toFixed(1);
    const cls = isOver ? 'danger-row' : 'warn-row';
    html += `
      <div class="modal-row ${cls}">
        <span class="modal-key">Batas Pengeluaran</span>
        <span class="modal-val">${fmt(limit)}</span>
      </div>
      <div class="modal-row ${cls}">
        <span class="modal-key">Persentase Batas</span>
        <span class="modal-val">${pct}%${isOver ? ' — MELEBIHI!' : ''}</span>
      </div>
    `;
  }

  document.getElementById('modal-body').innerHTML = html;

  // Tampilkan modal
  document.getElementById('modal-backdrop').classList.add('show');
  document.getElementById('modal-summary').classList.add('show');
}

function closeModal() {
  document.getElementById('modal-backdrop').classList.remove('show');
  document.getElementById('modal-summary').classList.remove('show');
}

/* ══════════════════════════════════════════
   BATAS PENGELUARAN
══════════════════════════════════════════ */

function saveLimit() {
  const val = parseFloat(document.getElementById('limit-input').value);
  if (!val || val <= 0) {
    showToast('Gagal', 'Masukkan angka positif untuk batas pengeluaran.', 'error');
    return;
  }
  limit = val;
  localStorage.setItem('dompetku_limit', limit);
  renderAll();
  showToast('Batas Ditetapkan', 'Batas pengeluaran bulanan: ' + fmt(limit), 'success');
  checkLimit();
}

/** Cek apakah pengeluaran melebihi batas; tampilkan peringatan jika ya */
function checkLimit() {
  if (limit <= 0) return;
  const filtered = getFiltered();
  const total    = filtered.reduce((s, e) => s + e.amount, 0);
  if (total > limit) {
    const over = total - limit;
    showToast(
      '⚠️ Batas Terlampaui!',
      `Pengeluaran ${monthLabel(activeMonth)} sebesar ${fmt(total)} melebihi batas ${fmt(limit)}. Selisih: ${fmt(over)}.`,
      'warn'
    );
  }
}

/* ══════════════════════════════════════════
   HAPUS SEMUA DATA
══════════════════════════════════════════ */

function clearAllData() {
  if (!confirm('PERINGATAN: Semua data pengeluaran akan dihapus permanen. Lanjutkan?')) return;
  entries = [];
  saveToStorage();
  renderAll();
  showToast('Semua Data Dihapus', 'Seluruh data pengeluaran telah dihapus.', 'error');
}

/* ══════════════════════════════════════════
   STORAGE INFO (Sidebar)
══════════════════════════════════════════ */

function updateStorageInfo() {
  const count = entries.length;
  const pct   = Math.min((count / 500) * 100, 100); // anggap max 500 entri = 100%
  document.getElementById('storage-fill').style.width = pct.toFixed(0) + '%';
  document.getElementById('storage-info').textContent = count + ' transaksi tersimpan';
}

/* ══════════════════════════════════════════
   TOAST NOTIFIKASI
══════════════════════════════════════════ */

let toastTimer = null;

/**
 * Tampilkan toast notifikasi
 * @param {string} title - Judul notifikasi
 * @param {string} msg   - Pesan
 * @param {'success'|'warn'|'error'} type - Jenis
 */
function showToast(title, msg, type = 'success') {
  const toast  = document.getElementById('toast');
  const icon   = document.getElementById('toast-icon');
  const titleEl = document.getElementById('toast-title');
  const msgEl  = document.getElementById('toast-msg');

  // Reset class
  toast.className = 'toast';

  if (type === 'warn')  { toast.classList.add('toast-warn');  icon.textContent = '⚠'; }
  else if (type === 'error') { toast.classList.add('toast-error'); icon.textContent = '✕'; }
  else { icon.textContent = '✓'; }

  titleEl.textContent = title;
  msgEl.textContent   = msg;

  toast.classList.add('show');

  // Auto-dismiss setelah 4 detik
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => closeToast(), 4000);
}

function closeToast() {
  document.getElementById('toast').classList.remove('show');
}

/* ══════════════════════════════════════════
   UTILITAS
══════════════════════════════════════════ */

/** Format tanggal YYYY-MM-DD ke DD/MM/YYYY */
function formatDate(dateStr) {
  const [y, m, d] = dateStr.split('-');
  return `${d}/${m}/${y}`;
}

/** Escape HTML untuk mencegah XSS */
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
